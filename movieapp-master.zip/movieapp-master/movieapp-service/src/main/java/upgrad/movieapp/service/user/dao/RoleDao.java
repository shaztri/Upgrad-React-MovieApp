package upgrad.movieapp.service.user.dao;

import upgrad.movieapp.service.common.dao.BaseDao;
import upgrad.movieapp.service.user.entity.RoleEntity;

public interface RoleDao extends BaseDao<RoleEntity> {

}
